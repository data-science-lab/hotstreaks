Each folder contains indiviudal profiles in the domain.
1) Artist:
artists.txt 
	- Each line is the list of works for an individual,
	- Works within a career are splited by '|'
	- For each work, the first element is hammer price, and the second element is  year of production
2) Director:
directors.txt 
	- Each line is the list of works for an individual,
	- Works within a career are splited by '|'
	- For each work, the first element is IMDB rating, and the second element is year of release
3) Scienitst:
scientists_c10.txt 
	- Each line is the list of works for an individual,				   
	- Works within a career are splited by '|'
	- For each work, the first element is raw C10, the second element is rescale C10, the third element is publication year
citation.zip       
	- All citation for each indiviudal 
	- Each line is a paper, where the first element is publication time, and the rest is the citation of each paper


